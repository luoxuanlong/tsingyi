// 荆州关键地点坐标 (基于 968x883 底图)
const CITY_COORDS = {
    // 曹魏核心
    "宛":            { x: 340, y: 85 },
    "新野":          { x: 395, y: 185 },
    "樊城":          { x: 375, y: 248 },
    "襄阳":          { x: 400, y: 260 },
    "章陵":          { x: 485, y: 195 },
    "当阳":          { x: 320, y: 365 },
    "汝南":          { x: 720, y: 130 },
    "谯":            { x: 870, y: 130 },
    "上庸":          { x: 180, y: 245 },
    "房陵":          { x: 200, y: 195 },
    "沔北/石阳":     { x: 595, y: 345 },
    "摩陂":          { x: 490, y: 110 },

    // 南郡
    "江陵":          { x: 415, y: 410 },
    "公安":          { x: 435, y: 475 },
    "夷陵":          { x: 255, y: 415 },
    "宜都":          { x: 310, y: 425 },
    "临沮":          { x: 350, y: 340 },
    "旌阳":          { x: 370, y: 355 },

    // 江夏
    "夏口":          { x: 640, y: 380 },
    "沙羡":          { x: 660, y: 415 },
    "陆口":          { x: 545, y: 445 },
    "柴桑":          { x: 740, y: 395 },
    "寻阳":          { x: 795, y: 395 },
    "官亭":          { x: 710, y: 360 },
    "巴丘":          { x: 505, y: 495 },
    "夷陵州/州上":   { x: 480, y: 430 },

    // 荆南
    "武陵":          { x: 295, y: 595 },
    "长沙":          { x: 490, y: 645 },
    "零陵":          { x: 370, y: 715 },
    "桂阳":          { x: 570, y: 725 },
    "益阳":          { x: 425, y: 610 },
    "临烝":          { x: 460, y: 665 },
    "武昌":          { x: 685, y: 510 },

    // 赤壁战场
    "赤壁":          { x: 540, y: 400 },
    "乌林":          { x: 520, y: 395 },
    "华容":          { x: 375, y: 400 },
    "博望":          { x: 350, y: 170 },
    "长坂":          { x: 345, y: 355 },
    "麦城":          { x: 360, y: 415 },
    "章乡":          { x: 340, y: 445 },

    // 濡须/东线（参考）
    "濡须":          { x: 870, y: 320 },
    "合肥":          { x: 860, y: 250 },
};

// 三方颜色
const FACTION_COLORS = {
    wei:   { main: '#c0392b', light: '#ffcccb', name: '曹魏' },
    liu:   { main: '#27ae60', light: '#c8e6c9', name: '刘备/蜀' },
    sun:   { main: '#2980b9', light: '#bbdefb', name: '孙权/吴' },
    event: { main: '#8e44ad', light: '#e1bee7', name: '事件' },
};

// 年份数据
// unit: 兵力单位为"万"；cav=骑兵 inf=步兵 nav=水军(船)  c=骑兵/艘 步=步兵 船=船
// strength: "A"明载 "B"推算 "C"推测
const YEARS_DATA = {

"207": {
    title: "建安十二年（207）·南阳对峙",
    subtitle: "曹操平定河北，兵临南阳；刘备屯新野为刘表北藩；孙权西讨黄祖",
    events: [
        { text: "五月曹操北征乌桓，八月破白狼山，河北平定", ref: "《武帝纪》" },
        { text: "刘备为刘表北藩，屯新野；博望设伏击夏侯惇（202年旧事）", ref: "《先主传》《李典传》" },
        { text: "孙权西征黄祖，虏其人民而还（试探性进攻）", ref: "《吴主传》" },
    ],
    wei: [
        { loc: "宛", gen: "南阳郡戍（名不详）", total: "0.5-0.8万", cav: "500-1000", inf: "0.45-0.7万", nav: 0, note: "南阳郡兵", strength: "C" },
        { loc: "新野以北-许南", gen: "于禁·虎威将军", total: "0.4-0.5万", cav: "500-800", inf: "0.35-0.42万", nav: 0, note: "二线屯兵", strength: "C" },
        { loc: "颍川阳翟", gen: "乐进", total: "0.3-0.4万", cav: "300-500", inf: "0.27-0.35万", nav: 0, note: "荆州未服遣屯", strength: "A驻地/C" },
        { loc: "颍川长社", gen: "张辽·荡寇将军", total: "0.3-0.4万", cav: 500, inf: "0.25-0.35万", nav: 0, note: "荆州未定遣屯", strength: "A驻地/C" },
        { loc: "洛阳-许", gen: "夏侯惇·伏波将军", total: "0.5-0.7万", cav: "1000-1500", inf: "0.4-0.55万", nav: 0, note: "南线后方支点", strength: "C" },
        { loc: "邺城-许", gen: "李典·捕虏将军", total: "0.2-0.3万", cav: "300-500", inf: "0.17-0.25万", nav: 0, note: "机动兵团", strength: "C" },
    ],
    liu: [
        { loc: "新野", gen: "刘备自将 + 关羽/张飞", total: "0.8-1.0万", cav: "数百", inf: "0.7-0.9万", nav: 0, note: "9000人左右，大营+分屯", strength: "B" },
        { loc: "博望", gen: "前哨（张飞/赵云轮驻）", total: "约1000", cav: 0, inf: "约1000", nav: 0, note: "北门前哨预警", strength: "C" },
    ],
    sun: [
        { loc: "官亭-柴桑", gen: "周瑜·中护军前部", total: "0.5-0.8万", cav: "100-200", inf: "0.2-0.3万", nav: "0.3-0.5万", note: "前敌指挥", strength: "A/C" },
        { loc: "柴桑", gen: "徐盛·柴桑长", total: "约500", cav: 0, inf: 200, nav: 300, note: "吴军最西桥头堡", strength: "A" },
        { loc: "寻阳-剧县", gen: "吕蒙·都尉", total: "0.1-0.2万", cav: 0, inf: "0.05-0.1万", nav: "0.05-0.1万", note: "守备", strength: "C" },
        { loc: "鄱阳-寻阳", gen: "凌统·承烈都尉", total: "0.1-0.2万", cav: 0, inf: "0.05-0.1万", nav: "0.05-0.1万", note: "守备", strength: "C" },
        { loc: "乐安", gen: "韩当·先登校尉", total: "约2000", cav: 50, inf: 1000, nav: 950, note: "授兵二千骑五十匹", strength: "A" },
    ],
    arrows: [
        { from: "邺城-许", to: "宛", faction: "wei", label: "河北平定", kind: "land" },
    ],
    battles: [],
},

"208_1": {
    title: "建安十三年（208）春·破黄祖",
    subtitle: "孙权屠夏口灭黄祖；曹操作玄武池练水军",
    events: [
        { text: "春，孙权西征黄祖，吕蒙破其前锋，董袭断绁，屠夏口，黄祖亡", ref: "《吴主传》《董袭传》" },
        { text: "正月曹操还邺，作玄武池以肄舟师", ref: "《武帝纪》" },
    ],
    wei: [
        { loc: "宛-新野", gen: "南阳郡戍", total: "0.6-0.9万", cav: "600-1000", inf: "0.54-0.8万", nav: 0, note: "备战南征", strength: "C" },
    ],
    liu: [
        { loc: "新野", gen: "刘备自将", total: "约1万", cav: 0, inf: "约1万", nav: 0, note: "刘表北藩", strength: "C" },
    ],
    sun: [
        { loc: "夏口江面", gen: "周瑜·前部大督", total: "1.0-1.5万", cav: "100-200", inf: "0.4-0.6万", nav: "0.6-0.8万", note: "征黄祖主力", strength: "A/B" },
        { loc: "夏口", gen: "吕蒙·都尉", total: "0.2-0.3万", cav: 0, inf: "0.1-0.15万", nav: "0.1-0.15万", note: "前锋破黄祖", strength: "A/C" },
        { loc: "夏口", gen: "凌统·承烈都尉", total: "0.1-0.2万", cav: 0, inf: "0.05-0.1万", nav: "0.05-0.1万", note: "敢死队", strength: "A/C" },
        { loc: "夏口", gen: "董袭·偏将军", total: "0.1-0.2万", cav: 0, inf: "0.05-0.1万", nav: "0.05-0.1万", note: "断绁敢死队", strength: "A/C" },
        { loc: "夏口", gen: "孙权自将", total: "0.3-0.5万", cav: 100, inf: "0.1-0.2万", nav: "0.2-0.3万", note: "中军", strength: "C" },
        { loc: "柴桑", gen: "徐盛·柴桑长", total: 500, cav: 0, inf: 200, nav: 300, note: "后方留守", strength: "A" },
    ],
    arrows: [
        { from: "柴桑", to: "夏口", faction: "sun", label: "西征黄祖", kind: "naval" },
    ],
    battles: [
        { loc: "夏口", name: "夏口之战", note: "吕蒙破前锋·董袭断绁" },
    ],
},

"208_2": {
    title: "建安十三年（208）秋·曹操南征",
    subtitle: "刘琮降，曹操入襄阳、取江陵；刘备南走；孙刘联盟",
    events: [
        { text: "七月曹操南征刘表；八月表卒，琮嗣；九月曹至新野，琮降", ref: "《武帝纪》" },
        { text: "刘备南走，曹操遣曹纯率精骑五千追至长坂，备败走夏口", ref: "《先主传》" },
        { text: "曹操入襄阳、进江陵，尽得刘表舟船军资", ref: "《周瑜传》" },
        { text: "诸葛亮出使东吴，促成孙刘联盟", ref: "《诸葛亮传》" },
    ],
    wei: [
        { loc: "随曹操南征", gen: "七军（于禁、张辽、张郃等）+ 赵俨都督护军", total: "4-5万", cav: "0.5-0.7万", inf: "3.5-4.3万", nav: 0, note: "七军建制", strength: "A/B" },
        { loc: "随曹操南征", gen: "曹纯·虎豹骑", total: "5000", cav: "5000", inf: 0, nav: 0, note: "精骑五千追长坂", strength: "A" },
        { loc: "随曹操南征", gen: "其他诸将部与州郡兵", total: "8-10万", cav: "0.6-0.8万", inf: "7.4-9.2万", nav: 0, note: "中原兵其他部分", strength: "C" },
        { loc: "江陵-赤壁沿江", gen: "刘表降水军（文聘等）", total: "2.5-3.5万", cav: 0, inf: 0, nav: "2.5-3.5万", note: "蒙冲斗舰千数", strength: "A船千数/B" },
        { loc: "襄阳-江陵", gen: "刘表降步骑", total: "4-4.5万", cav: "0.2-0.3万", inf: "3.8-4.2万", nav: 0, note: "表众七八万", strength: "A七八万/B" },
        { loc: "许昌-洛阳后方", gen: "曹操本部+许洛留守", total: "3-4万", cav: "2000-3000", inf: "2.8-3.7万", nav: 0, note: "留守中原", strength: "C" },
    ],
    liu: [
        { loc: "南走夏口", gen: "刘备自将（本部残兵）", total: "约数千", cav: 0, inf: "约数千", nav: 0, note: "长坂溃败剩余", strength: "B" },
        { loc: "夏口", gen: "关羽水军", total: "约数千", cav: 0, inf: 0, nav: "约数千", note: "精甲万人之一部", strength: "A" },
        { loc: "夏口", gen: "刘琦·江夏太守", total: "约1万", cav: 0, inf: "约1万", nav: 0, note: "江夏兵万人", strength: "A" },
    ],
    sun: [
        { loc: "夏口", gen: "周瑜·左督", total: "2万", cav: "200-300", inf: "0.8-0.9万", nav: "1-1.1万", note: "精兵三万", strength: "A各领万人/B" },
        { loc: "夏口", gen: "程普·右督", total: "1万", cav: "100-150", inf: "0.4-0.45万", nav: "0.5-0.55万", note: "右督", strength: "A各领万人/B" },
    ],
    arrows: [
        { from: "宛", to: "新野", faction: "wei", label: "曹操七军南征", kind: "land" },
        { from: "新野", to: "襄阳", faction: "wei", label: "入襄阳·琮降", kind: "land" },
        { from: "襄阳", to: "江陵", faction: "wei", label: "取江陵", kind: "land" },
        { from: "新野", to: "长坂", faction: "wei", label: "曹纯虎豹骑五千", kind: "cav" },
        { from: "新野", to: "长坂", faction: "liu", label: "刘备携民南走", kind: "land", dashed: true },
        { from: "长坂", to: "夏口", faction: "liu", label: "备败走夏口", kind: "land", dashed: true },
    ],
    battles: [
        { loc: "长坂", name: "长坂坡之战", note: "曹纯五千追刘备·张飞断后" },
    ],
},

"208_3": {
    title: "建安十三年（208）冬·赤壁之战",
    subtitle: "黄盖诈降火攻，曹操大败北还；留曹仁等守荆州",
    events: [
        { text: "孙刘联军与曹军遇于赤壁，初一交战，曹军败退引次江北（乌林）", ref: "《周瑜传》" },
        { text: "黄盖诈降，十艘蒙冲斗舰乘风纵火，烧尽北船及岸上营落", ref: "《周瑜传》" },
        { text: "曹操烧其余船引退，华容道步归，大疫，吏士多死者", ref: "《武帝纪》《山阳公载记》" },
        { text: "曹操北还，留曹仁、徐晃守江陵，乐进守襄阳，文聘守江夏", ref: "《吴主传》" },
    ],
    wei: [
        { loc: "江陵", gen: "曹仁·行征南将军", total: "1.5-2.5万", cav: "0.2-0.3万", inf: "1.3-2.2万", nav: "残船数百", note: "江陵主守", strength: "A留守/B" },
        { loc: "樊城-江陵", gen: "徐晃·横野将军", total: "0.3-0.5万", cav: "500-800", inf: "0.25-0.42万", nav: 0, note: "别屯后合守", strength: "A《徐晃传》/C" },
        { loc: "襄阳", gen: "乐进", total: "0.5-0.8万", cav: "500-1000", inf: "0.45-0.7万", nav: 0, note: "守襄阳", strength: "A/C" },
        { loc: "当阳", gen: "满宠·行奋威将军", total: "0.2-0.3万", cav: "300-500", inf: "0.17-0.25万", nav: 0, note: "江陵北面屏障", strength: "A/C" },
        { loc: "江夏北部", gen: "文聘·江夏太守", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "典北兵", strength: "A/C" },
        { loc: "章陵", gen: "赵俨·章陵太守、都督护军", total: "0.2-0.3万", cav: "200-300", inf: "0.18-0.27万", nav: 0, note: "襄阳东北", strength: "A/C" },
    ],
    liu: [
        { loc: "江陵外围-夏水", gen: "刘备自将", total: "约3000", cav: 0, inf: "约3000", nav: 0, note: "自夏水迂回江陵东北", strength: "B" },
        { loc: "汉水中游", gen: "关羽（苏非副之）", total: "3000-5000", cav: 0, inf: "约2000", nav: "1000-3000", note: "绝北道（切断襄阳→江陵补给）", strength: "《李通传》/B" },
        { loc: "夏口", gen: "刘琦", total: "约1万", cav: 0, inf: "约1万", nav: 0, note: "江夏守军未参战", strength: "A" },
    ],
    sun: [
        { loc: "赤壁南岸", gen: "周瑜·左督", total: "2万", cav: "200-300", inf: "0.8-0.9万", nav: "1-1.1万", note: "赤壁主力", strength: "A/B" },
        { loc: "赤壁南岸", gen: "程普·右督", total: "1万", cav: "100-150", inf: "0.4-0.45万", nav: "0.5-0.55万", note: "赤壁主力", strength: "A/B" },
        { loc: "乌林", gen: "黄盖", total: "含于周瑜部", cav: 0, inf: 0, nav: "蒙冲十艘走舸若干", note: "火攻前锋", strength: "A" },
        { loc: "江陵", gen: "周瑜·南郡太守", total: "2-3万", cav: "300-500", inf: "0.8-1.2万", nav: "1-1.5万", note: "赤壁后围江陵", strength: "A领南郡/B" },
        { loc: "沙羡", gen: "程普·江夏太守", total: "0.5-1万", cav: 50-100, inf: "0.2-0.3万", nav: "0.3-0.7万", note: "治沙羡", strength: "A治沙羡/C" },
        { loc: "夷陵", gen: "甘宁", total: "约1000", cav: 0, inf: 500, nav: 500, note: "前据夷陵", strength: "A《甘宁传》" },
    ],
    arrows: [
        { from: "江陵", to: "乌林", faction: "wei", label: "曹操沿江东下", kind: "naval" },
        { from: "夏口", to: "赤壁", faction: "sun", label: "周瑜·程普联军", kind: "naval" },
        { from: "赤壁", to: "夷陵", faction: "sun", label: "甘宁前据夷陵", kind: "naval" },
        { from: "江陵", to: "华容", faction: "wei", label: "曹操败走华容道", kind: "land", dashed: true },
    ],
    battles: [
        { loc: "赤壁", name: "赤壁之战", note: "黄盖十艘蒙冲诈降·纵火焚船" },
        { loc: "乌林", name: "乌林之溃", note: "北船烧尽·岸上营落皆焚" },
    ],
},

"209": {
    title: "建安十四年（209）·江陵之围",
    subtitle: "周瑜、程普围曹仁岁余；关羽绝北道；公安立营；曹仁弃城北走",
    events: [
        { text: "周瑜、程普围江陵，与曹仁各隔大江；甘宁守夷陵，曹仁分兵五六千围之", ref: "《周瑜传》《甘宁传》" },
        { text: "关羽别遣绝北道，李通率众救仁，道病卒", ref: "《李通传》" },
        { text: "周瑜分南岸地给刘备，备立营油江口，改名公安", ref: "《江表传》" },
        { text: "曹仁终弃城走，周瑜遂据南郡", ref: "《吕蒙传》" },
        { text: "曹操在谯作轻舟治水军；张辽、乐进、李典7000余人屯合肥", ref: "《张辽传》" },
    ],
    wei: [
        { loc: "江陵", gen: "曹仁", total: "1.5-2万", cav: "0.2-0.3万", inf: "1.3-1.7万", nav: "少量残船", note: "周瑜数万来攻", strength: "A/B" },
        { loc: "夷陵方向", gen: "曹仁别将", total: "0.5-0.6万", cav: "500-800", inf: "0.45-0.52万", nav: 0, note: "分遣围甘宁", strength: "A《甘宁传》" },
        { loc: "襄阳", gen: "乐进", total: "0.5-0.8万", cav: 500, inf: "0.45-0.75万", nav: 0, note: "乐进守襄阳", strength: "A/C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: 300, inf: "0.27-0.47万", nav: 0, note: "文聘镇江夏北", strength: "A/C" },
        { loc: "当阳-汝南", gen: "满宠", total: "0.2-0.3万", cav: 300, inf: "0.17-0.27万", nav: 0, note: "当阳弃守北调汝南", strength: "A/C" },
    ],
    liu: [
        { loc: "公安（油江口）", gen: "刘备自将", total: "1-1.5万", cav: 0, inf: "0.5-0.8万", nav: "0.5-0.7万", note: "水陆双营立此", strength: "B" },
        { loc: "江北-汉津", gen: "关羽·襄阳太守（遥领）", total: "约1万", cav: 0, inf: "约3000", nav: "约7000", note: "驻江北（江陵方向）", strength: "A" },
        { loc: "宜都", gen: "张飞·宜都太守", total: "0.5-0.8万", cav: 0, inf: "0.4-0.6万", nav: "0.1-0.2万", note: "防益州东出", strength: "A" },
        { loc: "四郡", gen: "金旋/韩玄/赵范/刘度降", total: "约1万", cav: 0, inf: "约1万", nav: 0, note: "武陵长沙桂阳零陵降", strength: "A" },
    ],
    sun: [
        { loc: "江陵", gen: "周瑜·南郡太守", total: "2-3万", cav: "300-500", inf: "0.8-1.2万", nav: "1-1.5万", note: "围江陵主力", strength: "A" },
        { loc: "夷陵", gen: "甘宁", total: "约1000", cav: 0, inf: 500, nav: 500, note: "仅满千人被围", strength: "A" },
        { loc: "江陵后方", gen: "凌统", total: "0.2-0.3万", cav: 0, inf: 1000, nav: "0.1-0.2万", note: "吕蒙计留凌统守后", strength: "A/C" },
        { loc: "沙羡", gen: "程普·江夏太守", total: "0.5-1万", cav: 50-100, inf: "0.2-0.3万", nav: "0.3-0.7万", note: "江夏", strength: "A/C" },
    ],
    arrows: [
        { from: "赤壁", to: "江陵", faction: "sun", label: "周瑜围江陵", kind: "naval" },
        { from: "赤壁", to: "夷陵", faction: "sun", label: "甘宁守夷陵", kind: "land" },
        { from: "夏口", to: "汉水中游", faction: "liu", label: "关羽绝北道", kind: "land" },
        { from: "江陵", to: "公安", faction: "liu", label: "刘备立营油江口", kind: "land" },
        { from: "江陵", to: "当阳", faction: "wei", label: "曹仁北走", kind: "land", dashed: true },
    ],
    battles: [
        { loc: "江陵", name: "江陵之围", note: "周瑜·程普围曹仁岁余·仁弃城走" },
        { loc: "夷陵", name: "夷陵之守", note: "甘宁千余人拒曹仁五六千" },
    ],
},

"210": {
    title: "建安十五年（210）·借南郡与汉水防线定型",
    subtitle: "周瑜卒，鲁肃代领；孙权借南郡与刘备；曹魏退守襄樊一线",
    events: [
        { text: "周瑜卒，鲁肃代领其兵；孙权分长沙为汉昌郡，肃屯陆口", ref: "《吴主传》《鲁肃传》" },
        { text: "孙权将南郡借与刘备，刘备得江陵", ref: "《鲁肃传》" },
        { text: "曹操下求贤令、作铜爵台", ref: "《武帝纪》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·行征南将军", total: "0.8-1.2万", cav: "0.2-0.3万", inf: "0.6-0.9万", nav: 0, note: "镇荆州", strength: "A" },
        { loc: "襄阳", gen: "乐进", total: "0.5-0.8万", cav: "500-800", inf: "0.45-0.72万", nav: 0, note: "襄阳与樊城互为犄角", strength: "A/C" },
        { loc: "石阳/沔北", gen: "文聘·江夏太守", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "江夏数十年", strength: "A/C" },
    ],
    liu: [
        { loc: "公安", gen: "刘备·荆州牧", total: "约1万", cav: 0, inf: "约5000", nav: "约5000", note: "治公安", strength: "A" },
        { loc: "江陵", gen: "关羽·襄阳太守（遥领）", total: "1-1.2万", cav: 0, inf: "0.5-0.6万", nav: "0.5-0.6万", note: "驻江北（江陵）", strength: "A" },
        { loc: "南郡", gen: "张飞·后转南郡", total: "0.5-0.8万", cav: 0, inf: "0.4-0.6万", nav: "0.1-0.2万", note: "机动策应", strength: "A" },
        { loc: "临烝", gen: "诸葛亮·军师中郎将", total: "文吏民夫", cav: 0, inf: "少量护卫", nav: 0, note: "督三郡赋税", strength: "A" },
        { loc: "公安留营", gen: "赵云·留营司马", total: "亲兵数千", cav: 0, inf: "亲兵数千", nav: 0, note: "掌内事", strength: "A" },
    ],
    sun: [
        { loc: "陆口", gen: "鲁肃·汉昌太守、奋武校尉", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "众增万余", strength: "A众万余/B" },
        { loc: "沙羡-夏口", gen: "程普（后孙皎）·江夏太守", total: "0.5-0.8万", cav: 50-100, inf: "0.2-0.3万", nav: "0.3-0.5万", note: "江夏", strength: "A/C" },
        { loc: "夏口", gen: "孙皎·都护征虏将军", total: "约2000余", cav: 0, inf: 1000, nav: 1000, note: "代程普督夏口", strength: "A领众二千余" },
        { loc: "寻阳", gen: "吕蒙", total: "0.2-0.3万", cav: 0, inf: "0.08-0.12万", nav: "0.12-0.18万", note: "奉邑寻阳", strength: "A/C" },
    ],
},

"211": {
    title: "建安十六年（211）·关中抽兵",
    subtitle: "曹操西征马超韩遂；曹仁西调潼关；荆州兵力空虚",
    events: [
        { text: "三月遣钟繇讨张鲁，马超等反；七月曹操西征夹潼关而军", ref: "《武帝纪》" },
        { text: "曹仁行安西将军，督诸将拒潼关，荆州主力被抽走", ref: "《曹仁传》" },
        { text: "刘备率步卒数万人入益州", ref: "《先主传》" },
    ],
    wei: [
        { loc: "襄阳", gen: "乐进（代守）", total: "0.5-0.8万", cav: "500-800", inf: "0.45-0.72万", nav: 0, note: "曹仁西调后乐进主持", strength: "C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "独当一面", strength: "A/C" },
        { loc: "宛", gen: "南阳郡将", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.47万", nav: 0, note: "空窗期", strength: "C" },
    ],
    liu: [
        { loc: "江陵", gen: "关羽·董督荆州事（准备中）", total: "1-1.5万", cav: 0, inf: "0.5-0.7万", nav: "0.5-0.8万", note: "留守", strength: "C" },
        { loc: "公安", gen: "诸葛亮、赵云留守", total: "约5000", cav: 0, inf: "约5000", nav: 0, note: "总揽后勤", strength: "C" },
    ],
    sun: [
        { loc: "陆口", gen: "鲁肃·汉昌太守", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "相持", strength: "A" },
        { loc: "夏口", gen: "孙皎·都护征虏将军", total: "0.3-0.5万", cav: 50-100, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "并黄盖孙瑜军", strength: "A/C" },
        { loc: "寻阳", gen: "吕蒙", total: "0.2-0.3万", cav: 0, inf: "0.08-0.12万", nav: "0.12-0.18万", note: "守备", strength: "A/C" },
    ],
},

"212": {
    title: "建安十七年（212）·曹仁回镇",
    subtitle: "曹操击孙权于濡须；曹仁平叛后回镇樊城",
    events: [
        { text: "正月曹操还邺，曹仁都督七军破河间苏伯田银", ref: "《曹仁传》" },
        { text: "曹仁复以行征南将军假节屯樊镇荆州", ref: "《曹仁传》" },
        { text: "十月曹操征孙权（下年正月攻濡须口）", ref: "《武帝纪》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·行征南将军", total: "0.8-1.2万", cav: "0.2-0.3万", inf: "0.6-0.9万", nav: 0, note: "回镇荆州", strength: "A" },
        { loc: "襄阳", gen: "乐进", total: "0.5-0.8万", cav: "500-800", inf: "0.45-0.72万", nav: 0, note: "襄阳", strength: "A/C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "江夏", strength: "A/C" },
    ],
    liu: [
        { loc: "江陵", gen: "关羽", total: "约1.5万", cav: 0, inf: "约7000", nav: "约8000", note: "留守荆州", strength: "C" },
    ],
    sun: [
        { loc: "陆口", gen: "鲁肃", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "相持", strength: "A" },
        { loc: "夏口", gen: "孙皎", total: "0.3-0.5万", cav: 50-100, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
    ],
},

"213": {
    title: "建安十八年（213）·濡须大战·荆扬联动",
    subtitle: "曹操号四十万攻濡须；乐进文聘与关羽汉水拉锯",
    events: [
        { text: "正月曹操进军濡须口，号步骑四十万，破孙权江西营", ref: "《武帝纪》" },
        { text: "乐进击关羽于青泥，走之；南郡山谷蛮夷转附乐进", ref: "《乐进传》" },
        { text: "文聘与乐进讨关羽于寻口，有功；又攻羽辎重于汉津", ref: "《文聘传》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·征南将军", total: "0.8-1.2万", cav: "0.2-0.3万", inf: "0.6-0.9万", nav: 0, note: "汉水防线", strength: "A/C" },
        { loc: "襄阳", gen: "乐进", total: "0.5-0.8万", cav: "500-800", inf: "0.45-0.72万", nav: 0, note: "青泥之战胜羽", strength: "A/C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "与乐进合击关羽", strength: "A" },
    ],
    liu: [
        { loc: "江陵-青泥-寻口", gen: "关羽", total: "约1万", cav: 0, inf: "约5000", nav: "约5000", note: "与乐进拉锯", strength: "《乐进传》" },
    ],
    sun: [
        { loc: "陆口", gen: "鲁肃", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "相持", strength: "A" },
        { loc: "夏口", gen: "孙皎", total: "0.3-0.5万", cav: 50-100, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
    ],
},

"214": {
    title: "建安十九年（214）·乐进转合肥",
    subtitle: "乐进随曹操征孙权后留屯合肥；吕常接防襄阳",
    events: [
        { text: "七月曹操征孙权；乐进假节；还留进与张辽李典屯合肥", ref: "《乐进传》" },
        { text: "乐进讨刘备临沮长杜普、旌阳长梁大，大破之", ref: "《乐进传》" },
        { text: "诸葛亮、张飞、赵云率众入蜀定郡县；关羽独守荆州", ref: "《诸葛亮传》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·征南将军", total: "0.8-1.2万", cav: "0.2-0.3万", inf: "0.6-0.9万", nav: 0, note: "镇荆州", strength: "A" },
        { loc: "襄阳", gen: "吕常（接防）", total: "0.5-0.8万", cav: "500-800", inf: "0.45-0.72万", nav: 0, note: "推测214年后接防", strength: "C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "江夏", strength: "A/C" },
    ],
    liu: [
        { loc: "江陵", gen: "关羽·董督荆州事", total: "约1万", cav: 0, inf: "约5000", nav: "约5000", note: "独守荆州", strength: "A" },
    ],
    sun: [
        { loc: "陆口", gen: "鲁肃", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "相持", strength: "A" },
        { loc: "夏口", gen: "孙皎", total: "0.3-0.5万", cav: 50-100, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
    ],
},

"215": {
    title: "建安二十年（215）·孙刘湘水划界",
    subtitle: "曹操平汉中；孙权合肥逍遥津之败；孙刘益阳对峙后湘水为界",
    events: [
        { text: "三月曹操西征张鲁，七月阳平，十一月张鲁降", ref: "《武帝纪》" },
        { text: "孙权遣吕蒙兵二万取三郡；鲁肃万人屯巴丘", ref: "《吴主传》" },
        { text: "刘备率五万下公安；关羽将三万入益阳对峙", ref: "《先主传》裴注" },
        { text: "甘宁以1300人拒关羽五千锐士于关羽濑", ref: "《甘宁传》" },
        { text: "湘水划界：长沙桂阳江夏属吴；南郡零陵武陵属备", ref: "《吴主传》" },
        { text: "孙权围合肥，张辽以800人突击大破之（逍遥津）", ref: "《张辽传》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·征南将军", total: "0.8-1.2万", cav: "0.2-0.3万", inf: "0.6-0.9万", nav: 0, note: "镇荆州", strength: "A" },
        { loc: "襄阳", gen: "吕常", total: "0.4-0.6万", cav: "500-800", inf: "0.35-0.52万", nav: 0, note: "襄阳", strength: "A/C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "江夏", strength: "A/C" },
    ],
    liu: [
        { loc: "益阳", gen: "关羽（号三万）", total: "号3万（实约2万）", cav: 0, inf: "约1.2万", nav: "约8000", note: "与鲁肃相拒", strength: "A号三万" },
        { loc: "公安", gen: "刘备·荆州牧", total: "5万（主力）", cav: 0, inf: "5万", nav: 0, note: "率五万下公安", strength: "A" },
        { loc: "江陵", gen: "糜芳·南郡太守", total: "数千", cav: 0, inf: "数千", nav: 0, note: "留守", strength: "C" },
    ],
    sun: [
        { loc: "长沙-零陵", gen: "吕蒙·偏将军", total: "2万", cav: "200-300", inf: "1-1.2万", nav: "0.8-1万", note: "取三郡", strength: "A兵二万" },
        { loc: "巴丘", gen: "鲁肃·横江将军", total: "1万", cav: "100-200", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "御关羽", strength: "A万人" },
        { loc: "益阳", gen: "鲁肃+甘宁", total: "约1.3万", cav: "100-200", inf: "0.7-0.8万", nav: "0.6-0.7万", note: "单刀会", strength: "A" },
        { loc: "陆口", gen: "孙权自将（中军）", total: "约1万", cav: "200-300", inf: "0.4-0.5万", nav: "0.5-0.6万", note: "诸军节度", strength: "C" },
    ],
    arrows: [
        { from: "柴桑", to: "益阳", faction: "sun", label: "吕蒙引兵西上", kind: "naval" },
        { from: "公安", to: "益阳", faction: "liu", label: "关羽三万南下", kind: "land" },
        { from: "成都", to: "公安", faction: "liu", label: "刘备五万东下", kind: "land" },
    ],
    battles: [
        { loc: "益阳", name: "益阳对峙", note: "双方面临大战·鲁肃单刀会" },
    ],
},

"216": {
    title: "建安二十一年（216）·魏王之岁",
    subtitle: "曹操进爵魏王；荆州无大战",
    events: [
        { text: "五月曹操进爵魏王；十月治兵征孙权", ref: "《武帝纪》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·征南将军", total: "0.8-1.2万", cav: "0.2-0.3万", inf: "0.6-0.9万", nav: 0, note: "镇荆州", strength: "A" },
        { loc: "襄阳", gen: "吕常", total: "0.4-0.6万", cav: "500-800", inf: "0.35-0.52万", nav: 0, note: "襄阳", strength: "A/C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "江夏", strength: "A/C" },
    ],
    liu: [
        { loc: "江陵", gen: "关羽·董督荆州事", total: "2-3万", cav: 0, inf: "约1.5万", nav: "约1万", note: "湘水后安心扩军", strength: "B" },
    ],
    sun: [
        { loc: "陆口", gen: "鲁肃", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "相持", strength: "A" },
        { loc: "夏口", gen: "孙皎", total: "0.3-0.5万", cav: 50-100, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
    ],
},

"217": {
    title: "建安二十二年（217）·曹仁东调",
    subtitle: "曹操居巢征孙权；曹仁东调居巢；荆州最空虚；鲁肃卒吕蒙代",
    events: [
        { text: "曹操军居巢，三月还，留夏侯惇、曹仁、张辽等屯居巢", ref: "《武帝纪》" },
        { text: "鲁肃卒，吕蒙代领其众，西屯陆口，肃军人马万余尽属蒙", ref: "《吕蒙传》" },
        { text: "孙权向曹操请降，吴魏暂时缓和", ref: "《吴主传》" },
    ],
    wei: [
        { loc: "襄阳", gen: "吕常", total: "0.4-0.6万", cav: "500-800", inf: "0.35-0.52万", nav: 0, note: "曹仁东调后襄阳独撑", strength: "A/C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "江夏", strength: "A/C" },
        { loc: "宛", gen: "南阳郡将", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.47万", nav: 0, note: "最低兵力年", strength: "C" },
    ],
    liu: [
        { loc: "江陵", gen: "关羽", total: "2-3万", cav: 0, inf: "约1.5万", nav: "约1万", note: "关羽强盛", strength: "C" },
    ],
    sun: [
        { loc: "陆口", gen: "吕蒙·汉昌太守", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "代鲁肃", strength: "A肃军万余属蒙" },
        { loc: "夏口", gen: "孙皎", total: "0.3-0.5万", cav: 50-100, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
    ],
},

"218": {
    title: "建安二十三年（218）·南阳侯音之变",
    subtitle: "曹操西征汉中；侯音叛于宛与关羽连和；曹仁回师平叛",
    events: [
        { text: "正月许都耿纪韦晃吉本反，事败", ref: "《武帝纪》" },
        { text: "七月曹操治兵西征汉中，九月至长安", ref: "《武帝纪》" },
        { text: "十月南阳侯音反，与关羽连和", ref: "《曹瞒传》" },
        { text: "曹仁率诸军讨侯音，破之，次年正月屠宛", ref: "《武帝纪》《曹仁传》" },
        { text: "乐进卒", ref: "《乐进传》" },
    ],
    wei: [
        { loc: "宛-樊城", gen: "曹仁·征南将军", total: "1.0-1.5万", cav: "0.2-0.3万", inf: "0.8-1.2万", nav: 0, note: "讨侯音", strength: "A讨侯音/C" },
        { loc: "襄阳", gen: "吕常", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "襄阳", strength: "A/C" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "江夏", strength: "A/C" },
        { loc: "汝南-樊城", gen: "满宠·汝南太守", total: "0.2-0.3万", cav: "200-300", inf: "0.18-0.27万", nav: 0, note: "侧翼", strength: "A/C" },
    ],
    liu: [
        { loc: "江陵", gen: "关羽", total: "3万以上", cav: 0, inf: "约2万", nav: "约1万", note: "策反侯音成功", strength: "C" },
    ],
    sun: [
        { loc: "陆口", gen: "吕蒙", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "相持", strength: "A" },
        { loc: "夏口", gen: "孙皎", total: "0.3-0.5万", cav: 50-100, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
    ],
},

"219_1": {
    title: "建安二十四年（219）夏·襄樊之战",
    subtitle: "关羽北攻樊城、围襄阳；于禁七军被汉水淹没",
    events: [
        { text: "正月曹仁屠宛斩侯音", ref: "《武帝纪》" },
        { text: "三月曹操自长安出斜谷，五月还长安（汉中拉锯）", ref: "《武帝纪》" },
        { text: "七月关羽率众攻曹仁于樊，又围吕常于襄阳", ref: "《关羽传》" },
        { text: "八月大霖雨汉水暴溢，于禁七军皆没；禁降、庞德被斩", ref: "《武帝纪》《关羽传》" },
        { text: "梁、郏、陆浑群盗遥受羽印号，羽威震华夏；曹操议徙许都", ref: "《关羽传》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·征南将军", total: "0.4-0.6万", cav: "500-1000", inf: "0.35-0.5万", nav: 0, note: "人马数千守城", strength: "A" },
        { loc: "樊城", gen: "满宠·汝南太守", total: "0.1-0.2万", cav: "100-200", inf: "0.09-0.18万", nav: 0, note: "助曹仁", strength: "A助仁/C" },
        { loc: "襄阳", gen: "吕常", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "被围", strength: "A被围/C" },
        { loc: "樊城北", gen: "于禁·左将军假节钺", total: "3万", cav: "0.2-0.3万", inf: "2.7-2.8万", nav: 0, note: "七军皆没", strength: "A步骑三万" },
        { loc: "樊北十里", gen: "庞德·立义将军", total: "0.3-0.5万", cav: "500-800", inf: "0.25-0.42万", nav: 0, note: "屯樊北", strength: "A/C" },
        { loc: "宛-阳陵陂", gen: "徐晃·平寇将军", total: "1.5-2.5万", cav: "0.2-0.3万", inf: "1.3-2.2万", nav: 0, note: "新卒+十二营", strength: "A屯宛十二营/B" },
        { loc: "洛阳-摩陂", gen: "曹操自将", total: "3-5万", cav: "0.5-0.8万", inf: "2.5-4.2万", nav: 0, note: "亲援后至", strength: "C" },
    ],
    liu: [
        { loc: "樊城-襄阳", gen: "关羽·前将军假节钺", total: "3-4万", cav: 0, inf: "约2万", nav: "约1.5万（舟兵数千）", note: "围樊围襄", strength: "A" },
        { loc: "江陵", gen: "糜芳·南郡太守", total: "约5000", cav: 0, inf: "约5000", nav: 0, note: "留守（兵多赴樊）", strength: "C" },
        { loc: "公安", gen: "士仁", total: "约2000", cav: 0, inf: "约2000", nav: 0, note: "留守", strength: "C" },
    ],
    sun: [
        { loc: "陆口", gen: "陆逊·偏将军右部督（代吕蒙）", total: "万余", cav: "200-300", inf: "0.5-0.6万", nav: "0.4-0.5万", note: "代吕蒙后关羽撤备", strength: "A" },
    ],
    arrows: [
        { from: "江陵", to: "襄阳", faction: "liu", label: "关羽北伐襄樊", kind: "land" },
        { from: "宛", to: "樊城", faction: "wei", label: "于禁·庞德增援", kind: "land" },
        { from: "襄阳", to: "沔北/石阳", faction: "liu", label: "关羽围石阳", kind: "land" },
    ],
    battles: [
        { loc: "沔北/石阳", name: "水淹七军", note: "秋大霖雨·于禁七军没·斩庞德" },
    ],
},

"219_2": {
    title: "建安二十四年（219）冬·吕蒙袭荆州",
    subtitle: "徐晃解围关羽退；吕蒙白衣渡江；关羽败走麦城被擒",
    events: [
        { text: "徐晃声东击西，破关羽四冢，羽自将步骑五千出战被击退", ref: "《徐晃传》" },
        { text: "关羽退围，曹仁、徐晃合势；曹操本部进至摩陂", ref: "《曹仁传》" },
        { text: "吕蒙白衣渡江，尽俘江边屯候，至公安士仁降，至江陵糜芳降", ref: "《吕蒙传》" },
        { text: "陆逊别取宜都，还屯夷陵守峡口", ref: "《陆逊传》" },
        { text: "朱然、潘璋断关羽归路；马忠擒羽于章乡", ref: "《潘璋传》《朱然传》" },
    ],
    wei: [
        { loc: "樊城", gen: "曹仁·征南将军", total: "数千", cav: 0, inf: "数千", nav: 0, note: "解围后", strength: "A" },
        { loc: "襄阳", gen: "吕常", total: "数千", cav: 0, inf: "数千", nav: 0, note: "解围后", strength: "A" },
        { loc: "偃城", gen: "徐晃·平寇将军", total: "1.5-2.5万", cav: "0.2-0.3万", inf: "1.3-2.2万", nav: 0, note: "解樊围", strength: "A" },
        { loc: "摩陂", gen: "曹操自将", total: "3-5万", cav: "0.5-0.8万", inf: "2.5-4.2万", nav: 0, note: "亲至前线", strength: "C" },
    ],
    liu: [
        { loc: "樊城前线", gen: "关羽", total: "仍约2-3万", cav: 0, inf: "约1.5万", nav: "约8000", note: "被徐晃击退", strength: "A" },
        { loc: "南归途中", gen: "关羽", total: "兵无斗心，军遂散", cav: 0, inf: "残部数千", nav: 0, note: "吕蒙入江陵，士兵家眷尽得，军散", strength: "《吕蒙传》" },
        { loc: "麦城-章乡", gen: "关羽（残部）", total: "十数骑", cav: "0-10", inf: 0, nav: 0, note: "败走被擒", strength: "A" },
    ],
    sun: [
        { loc: "寻阳-江陵", gen: "吕蒙·虎威将军大督", total: "2-3万", cav: "300-400", inf: "1-1.5万", nav: "0.8-1.2万", note: "白衣渡江", strength: "A大督/B" },
        { loc: "陆口-宜都", gen: "陆逊·前部", total: "0.5-1万", cav: "50-100", inf: "0.25-0.5万", nav: "0.25-0.5万", note: "取宜都", strength: "A前部/B" },
        { loc: "夏口-江陵", gen: "孙皎·都护征虏将军（后继）", total: "0.5-1万", cav: "50-100", inf: "0.25-0.5万", nav: "0.25-0.5万", note: "后继", strength: "A后继/C" },
        { loc: "临沮-夹石", gen: "朱然、潘璋", total: "0.6-1万", cav: "100-200", inf: "0.3-0.5万", nav: "0.3-0.5万", note: "断关羽归路", strength: "A/C" },
        { loc: "沔水", gen: "蒋钦·水军", total: "0.3-0.5万", cav: 0, inf: "0.1-0.2万", nav: "0.2-0.3万", note: "断汉水退路", strength: "A督水军入沔" },
    ],
    arrows: [
        { from: "柴桑", to: "公安", faction: "sun", label: "吕蒙白衣渡江", kind: "naval" },
        { from: "公安", to: "江陵", faction: "sun", label: "袭取江陵", kind: "land" },
        { from: "沔北/石阳", to: "临沮", faction: "liu", label: "关羽败退", kind: "land", dashed: true },
        { from: "临沮", to: "章乡", faction: "sun", label: "潘璋追至章乡", kind: "cav" },
    ],
    battles: [
        { loc: "江陵", name: "吕蒙袭荆州", note: "白衣渡江·公安降·江陵开城" },
        { loc: "章乡", name: "章乡之斩", note: "关羽父子为马忠所擒" },
    ],
},

"220": {
    title: "延康元年/黄初元年（220）·曹魏荆州建制化",
    subtitle: "曹操崩曹丕代汉；孟达降魏；夏侯尚破上庸；魏一度失襄阳旋复得",
    events: [
        { text: "正月曹操崩于洛阳，曹丕即王位", ref: "《文帝纪》" },
        { text: "秋孟达率众降魏，魏以孟达为新城太守", ref: "《明帝纪》裴注引《魏略》" },
        { text: "夏侯尚、徐晃击破上庸，平三郡九县", ref: "《夏侯尚传》" },
        { text: "孙权遣陈邵据襄阳；曹仁、徐晃攻破之复入襄阳", ref: "《曹仁传》" },
        { text: "冬曹丕禅汉称帝，改元黄初", ref: "《文帝纪》" },
    ],
    wei: [
        { loc: "襄阳-宛", gen: "曹仁·车骑将军都督荆扬益", total: "1-1.5万", cav: "0.2-0.3万", inf: "0.8-1.2万", nav: 0, note: "复入襄阳", strength: "A都督/C" },
        { loc: "宛-上庸", gen: "夏侯尚·征南将军领荆州刺史", total: "1-2万", cav: "0.2-0.3万", inf: "0.8-1.7万", nav: 0, note: "破上庸", strength: "A领刺史/B" },
        { loc: "新野", gen: "满宠·扬武将军", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.47万", nav: 0, note: "屯新野", strength: "A屯新野/C" },
        { loc: "石阳/沔北", gen: "文聘·江夏太守假节", total: "0.3-0.5万", cav: 300, inf: "0.27-0.47万", nav: 0, note: "江夏", strength: "A/C" },
        { loc: "房陵-上庸", gen: "孟达·新城太守", total: "0.4-0.6万", cav: 500, inf: "0.35-0.55万", nav: 0, note: "降魏", strength: "A/C" },
        { loc: "洵口", gen: "申仪·魏兴太守", total: "0.2-0.3万", cav: 200, inf: "0.18-0.28万", nav: 0, note: "降魏", strength: "A/C" },
    ],
    liu: [], // 刘备方此年在荆州无兵（已失）
    sun: [
        { loc: "江陵", gen: "朱然·昭武将军假节", total: "0.5-1万", cav: 50-100, inf: "0.2-0.4万", nav: "0.3-0.6万", note: "吕蒙卒后镇江陵", strength: "A镇江陵/C" },
        { loc: "公安", gen: "诸葛瑾·绥南将军代吕蒙", total: "0.5-1万", cav: 50-100, inf: "0.2-0.4万", nav: "0.3-0.6万", note: "住公安", strength: "A住公安/C" },
        { loc: "夷陵", gen: "陆逊·右护军镇西将军", total: "0.5-1万", cav: 50-100, inf: "0.25-0.5万", nav: "0.25-0.5万", note: "守峡口", strength: "A屯夷陵/C" },
        { loc: "夏口-沙羡", gen: "孙奂·扬武中郎将江夏太守", total: "0.2-0.5万", cav: 0, inf: "0.1-0.25万", nav: "0.1-0.25万", note: "代孙皎", strength: "A领江夏/C" },
        { loc: "夏口", gen: "潘濬·辅军中郎将", total: "0.3-0.5万", cav: 50, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "降吴授兵", strength: "A/C" },
    ],
},

"221": {
    title: "黄初二年（221）·夷陵之战前夜",
    subtitle: "刘备称帝；孙权称臣受封吴王；刘备率大军东下伐吴",
    events: [
        { text: "四月刘备称帝于成都，国号汉（蜀汉）", ref: "《先主传》" },
        { text: "八月前后孙权遣使称臣，送于禁还；十一月魏封吴王加九锡", ref: "《文帝纪》《吴主传》" },
        { text: "刘备率大军东下伐吴；武陵蛮夷响应", ref: "《先主传》《陆逊传》" },
        { text: "孙权以陆逊为大都督假节，督五万人拒刘备", ref: "《陆逊传》" },
    ],
    wei: [
        { loc: "襄阳-宛", gen: "曹仁·车骑将军", total: "1-1.5万", cav: "0.2-0.3万", inf: "0.8-1.2万", nav: 0, note: "都督荆扬益", strength: "A" },
        { loc: "宛-上庸", gen: "夏侯尚·征南大将军", total: "1-2万", cav: "0.2-0.3万", inf: "0.8-1.7万", nav: 0, note: "荆州刺史", strength: "A" },
        { loc: "新野", gen: "满宠", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.47万", nav: 0, note: "新野", strength: "A" },
        { loc: "江夏北", gen: "文聘", total: "0.3-0.5万", cav: 300, inf: "0.27-0.47万", nav: 0, note: "江夏", strength: "A" },
    ],
    liu: [
        { loc: "夷陵-猇亭", gen: "刘备自将+冯习张南等", total: "4-5万", cav: 0, inf: "4-5万", nav: "0.5-1万", note: "伐吴主力", strength: "B" },
        { loc: "武陵", gen: "马良·侍中", total: "约1万", cav: 0, inf: "约1万", nav: 0, note: "联结五溪蛮", strength: "C" },
    ],
    sun: [
        { loc: "夷陵-宜都", gen: "陆逊·大都督假节", total: "5万", cav: "500-800", inf: "2.5-3万", nav: "2-2.5万", note: "五万人拒备", strength: "A五万人" },
        { loc: "夷陵", gen: "朱然·昭武将军", total: "5000", cav: 50-100, inf: 2500, nav: 2500, note: "督五千并力拒备", strength: "A督五千" },
        { loc: "公安", gen: "诸葛瑾·左将军督公安", total: "0.5-1万", cav: 50-100, inf: "0.2-0.4万", nav: "0.3-0.6万", note: "督公安", strength: "A督公安/C" },
        { loc: "武陵", gen: "潘濬·辅军中郎将", total: "0.3-0.5万", cav: 0, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "讨五溪", strength: "A讨五溪/C" },
        { loc: "夏口", gen: "孙奂·江夏太守", total: "0.2-0.5万", cav: 0, inf: "0.1-0.25万", nav: "0.1-0.25万", note: "江夏", strength: "A/C" },
    ],
},

"222_1": {
    title: "黄初三年（222）闰六月·夷陵之战",
    subtitle: "陆逊火烧连营，大破刘备四十余营",
    events: [
        { text: "正月陆逊宋谦等破蜀五屯", ref: "《吴主传》" },
        { text: "闰月，陆逊大破刘备于夷陵猇亭，斩俘数万；刘备仅以身免", ref: "《吴主传》《陆逊传》" },
        { text: "陆逊不追刘备，回军备魏（判断曹丕有奸心）", ref: "《陆逊传》" },
    ],
    wei: [
        { loc: "襄阳-宛", gen: "曹仁·车骑将军", total: "1-1.5万", cav: "0.2-0.3万", inf: "0.8-1.2万", nav: 0, note: "待变", strength: "A" },
        { loc: "宛", gen: "夏侯尚·征南大将军", total: "1-2万", cav: "0.2-0.3万", inf: "0.8-1.7万", nav: 0, note: "待变", strength: "A" },
    ],
    liu: [
        { loc: "夷陵-猇亭", gen: "刘备（败军）", total: "损失数万", cav: 0, inf: "败走仅以身免", nav: 0, note: "大溃败", strength: "A" },
        { loc: "白帝城", gen: "刘备（驻守）", total: "约数千", cav: 0, inf: "约数千", nav: 0, note: "退驻白帝城", strength: "C" },
    ],
    sun: [
        { loc: "夷陵-西陵", gen: "陆逊·辅国将军荆州牧", total: "3-4万", cav: "400-600", inf: "1.5-2万", nav: "1.5-2万", note: "战后分守", strength: "A五万战后分守" },
        { loc: "夷陵前线", gen: "朱然、潘璋、韩当等", total: "约1-2万", cav: 0, inf: "约1万", nav: "约1万", note: "追击/扼守峡口", strength: "A/C" },
    ],
    arrows: [
        { from: "成都", to: "夷陵", faction: "liu", label: "刘备东征", kind: "land" },
        { from: "公安", to: "夷陵", faction: "liu", label: "水军东下", kind: "naval" },
        { from: "柴桑", to: "夷陵", faction: "sun", label: "陆逊西上", kind: "naval" },
    ],
    battles: [
        { loc: "夷陵", name: "夷陵之战", note: "陆逊火烧连营·刘备大败" },
    ],
},

"222_2": {
    title: "黄初三年（222）九月·曹魏三路伐吴",
    subtitle: "曹休出洞口、曹仁出濡须、曹真夏侯尚围江陵",
    events: [
        { text: "五月魏以江表八郡为荆州（名义），江北诸郡为郢州；九月孙权复叛", ref: "《文帝纪》" },
        { text: "曹丕自许昌南征，十一月行幸宛", ref: "《文帝纪》" },
        { text: "三路并进：曹休张辽臧霸出洞口；曹仁出濡须；曹真夏侯尚张郃徐晃围南郡", ref: "《吴主传》" },
        { text: "诸葛瑾潘璋杨粲救南郡；朱桓以五千人拒曹仁数万于濡须", ref: "《吴主传》《朱桓传》" },
    ],
    wei: [
        { loc: "江陵城下", gen: "曹真·中军大将军", total: "1.5-2.5万", cav: "0.2-0.3万", inf: "1.3-2.2万", nav: 0, note: "中军围江陵", strength: "A中军围江陵/C" },
        { loc: "江陵-江中", gen: "夏侯尚·征南大将军", total: "1.5-2万", cav: "0.15-0.25万", inf: "1.3-1.8万", nav: "数百油船", note: "步骑万余，下流潜渡破诸葛瑾", strength: "A步骑万余/C" },
        { loc: "江陵南渚/州上", gen: "张郃·左将军", total: "0.5-0.8万", cav: "500-1000", inf: "0.45-0.7万", nav: "少量", note: "取洲上屯坞", strength: "A取洲上屯坞/C" },
        { loc: "江陵", gen: "徐晃·右将军", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "围城", strength: "A/C" },
        { loc: "新野", gen: "满宠", total: "0.3-0.5万", cav: 300, inf: "0.27-0.47万", nav: 0, note: "后方", strength: "A/C" },
        { loc: "沔口-石梵", gen: "文聘", total: "0.3-0.5万", cav: 300, inf: "0.27-0.47万", nav: 0, note: "别屯沔口自当一队", strength: "A/C" },
        { loc: "新城", gen: "孟达", total: "0.4-0.6万", cav: 500, inf: "0.35-0.55万", nav: 0, note: "西翼", strength: "A/C" },
        { loc: "许昌-宛", gen: "曹丕自将（中军）", total: "2-4万", cav: "0.3-0.5万", inf: "1.7-3.5万", nav: "若干", note: "亲征至宛", strength: "C" },
        { loc: "濡须", gen: "曹仁·大司马", total: "2-3万", cav: "0.2-0.3万", inf: "1.8-2.7万", nav: "油船数千", note: "出濡须（扬州方向但联动）", strength: "A常雕5000/C" },
    ],
    liu: [
        { loc: "白帝城", gen: "刘备", total: "约数千", cav: 0, inf: "约数千", nav: 0, note: "退守白帝城", strength: "C" },
    ],
    sun: [
        { loc: "江陵", gen: "朱然·征北将军", total: "约5000（堪战）", cav: 50-100, inf: "2500-3000", nav: "2000-2500", note: "城中兵多肿病", strength: "A裁五千" },
        { loc: "江陵州上", gen: "孙盛", total: "1万", cav: "100-200", inf: 5000, nav: 5000, note: "备州上立围坞", strength: "A督万人" },
        { loc: "公安-江陵", gen: "诸葛瑾·左将军", total: "1-2万", cav: "100-200", inf: "0.5-1万", nav: "0.5-1万", note: "大兵救援", strength: "A大兵/C员额" },
        { loc: "江陵外围", gen: "潘璋、杨粲", total: "0.5-1万", cav: 50-100, inf: "0.25-0.5万", nav: "0.25-0.5万", note: "救南郡", strength: "A救南郡/C" },
        { loc: "夷陵-西陵", gen: "陆逊·荆州牧", total: "3-4万", cav: "400-600", inf: "1.5-2万", nav: "1.5-2万", note: "守峡口备蜀", strength: "A" },
        { loc: "武陵", gen: "潘濬", total: "0.3-0.5万", cav: 0, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
    ],
},

"223": {
    title: "黄初四年（223）·江陵保卫战·三国归势",
    subtitle: "魏军围江陵六月不克；因疫退兵；曹仁病逝；刘备崩于白帝城",
    events: [
        { text: "正月曹真分军据江陵中州，断内外联系", ref: "《吴主传》" },
        { text: "魏军围江陵六月，起土山凿地道立楼橹；朱然守，堪战者裁五千人", ref: "《朱然传》" },
        { text: "张郃渡兵攻孙盛于州上，盛不能退；诸葛瑾大兵救之不解", ref: "《朱然传》《诸葛瑾传》" },
        { text: "三月曹仁遣常雕等五千乘油船渡濡须中洲，为朱桓所破", ref: "《吴主传》《朱桓传》" },
        { text: "是月大疫，魏军皆退；曹仁薨", ref: "《文帝纪》" },
        { text: "四月刘备崩于白帝城；刘禅即位", ref: "《先主传》" },
    ],
    wei: [
        { loc: "江陵中州", gen: "曹真", total: "0.3-0.5万", cav: "500-800", inf: "0.25-0.42万", nav: 0, note: "分军据中州", strength: "A分军据中州/C" },
        { loc: "江陵城下", gen: "曹真、夏侯尚", total: "2-3万", cav: "0.3-0.4万", inf: "1.7-2.6万", nav: "少量油船", note: "围城主力", strength: "A/B" },
        { loc: "南渚/州上", gen: "张郃", total: "0.5-0.8万", cav: "500-1000", inf: "0.45-0.7万", nav: "少量", note: "据州上围守", strength: "A/C" },
        { loc: "江陵", gen: "徐晃", total: "0.3-0.5万", cav: "300-500", inf: "0.27-0.45万", nav: 0, note: "围城", strength: "A/C" },
        { loc: "濡须", gen: "曹仁·大司马", total: "2-3万", cav: "0.2-0.3万", inf: "1.8-2.7万", nav: "油船数千", note: "常雕5000覆没；旋薨", strength: "A常雕5000/C" },
        { loc: "新野/江夏/新城", gen: "满宠/文聘/孟达", total: "1-1.5万", cav: "0.1-0.15万", inf: "0.9-1.35万", nav: 0, note: "原防区", strength: "A/C" },
    ],
    liu: [
        { loc: "白帝城", gen: "刘备（崩）", total: "约数千", cav: 0, inf: "约数千", nav: 0, note: "四月崩；刘禅立", strength: "A" },
    ],
    sun: [
        { loc: "江陵", gen: "朱然·征北将军", total: "约5000（堪战）", cav: 50-100, inf: "2500-3000", nav: "2000-2500", note: "坚守六月", strength: "A裁五千" },
        { loc: "江陵州上", gen: "孙盛", total: "1万", cav: "100-200", inf: 5000, nav: 5000, note: "先退后进", strength: "A督万人" },
        { loc: "公安-江陵", gen: "诸葛瑾·左将军", total: "1-2万", cav: "100-200", inf: "0.5-1万", nav: "0.5-1万", note: "大兵救援", strength: "A大兵/C" },
        { loc: "江陵外围", gen: "潘璋、杨粲", total: "0.5-1万", cav: 50-100, inf: "0.25-0.5万", nav: "0.25-0.5万", note: "救应", strength: "A/C" },
        { loc: "江陵东南", gen: "韩当", total: "0.3-0.5万", cav: 0, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "保东南", strength: "A保东南/C" },
        { loc: "夷陵-西陵", gen: "陆逊·荆州牧", total: "3-4万", cav: "400-600", inf: "1.5-2万", nav: "1.5-2万", note: "守峡口", strength: "A" },
        { loc: "武陵", gen: "潘濬", total: "0.3-0.5万", cav: 0, inf: "0.15-0.25万", nav: "0.15-0.25万", note: "守备", strength: "A/C" },
        { loc: "夏口", gen: "孙奂", total: "0.2-0.5万", cav: 0, inf: "0.1-0.25万", nav: "0.1-0.25万", note: "江夏", strength: "A/C" },
    ],
    arrows: [
        { from: "宛", to: "新野", faction: "wei", label: "曹丕三路退兵南归", kind: "land", dashed: true },
    ],
    battles: [],
},

};

// 年份顺序（用于时间线导航）
const YEAR_ORDER = [
    "207",
    "208_1", "208_2", "208_3",
    "209", "210", "211", "212", "213", "214", "215", "216", "217", "218",
    "219_1", "219_2",
    "220", "221", "222_1", "222_2", "223",
];

// 三方总兵力概览（用于图表）
const ANNUAL_TOTALS = [
    { year: "207", wei: "2.2-3.1", liu: "0.8-1.0", sun: "1.2-2.0" },
    { year: "208", wei: "22-24", liu: "2", sun: "3.0-3.5" },
    { year: "209", wei: "2.8-4.1", liu: "2-3", sun: "3.0-4.0" },
    { year: "210", wei: "1.6-2.5", liu: "3+", sun: "1.9-2.4" },
    { year: "211", wei: "1.1-1.8", liu: "1.5-2", sun: "1.9-2.4" },
    { year: "212", wei: "1.6-2.5", liu: "1-1.5", sun: "1.9-2.4" },
    { year: "213", wei: "1.6-2.5", liu: "约1", sun: "1.9-2.4" },
    { year: "214", wei: "1.6-2.5", liu: "约1", sun: "1.9-2.4" },
    { year: "215", wei: "1.5-2.3", liu: "5+3", sun: "4.0-5.0" },
    { year: "216", wei: "1.5-2.3", liu: "2-3", sun: "2.0-3.0" },
    { year: "217", wei: "1.0-1.6", liu: "2-3", sun: "2.0-3.0" },
    { year: "218", wei: "1.8-2.8", liu: "3+", sun: "2.0-3.0" },
    { year: "219", wei: "6.5-8.5", liu: "3-4", sun: "5.0-6.0" },
    { year: "220", wei: "3.2-5.0", liu: 0, sun: "2.5-4.0" },
    { year: "221", wei: "3.2-5.0", liu: "4-5", sun: "5.0-6.5" },
    { year: "222", wei: "7-11", liu: "残部", sun: "6.0-8.0" },
    { year: "223", wei: "6-9", liu: "数千", sun: "4.0-6.0" },
];
